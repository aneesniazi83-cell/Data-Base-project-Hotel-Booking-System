-- ===================================================================
-- dbSQL.sql : Analytical Queries for Hotel Booking System
-- ===================================================================

USE HotelBookingDB;

-- ---------------------------------------------------------------
-- 1. List all bookings along with customer name, hotel name, room number.
--    (JOIN between Customer, Booking, Room, Hotel)
-- ---------------------------------------------------------------
SELECT 
    B.BookingID,
    C.FullName AS CustomerName,
    H.HotelName,
    R.RoomNumber,
    B.CheckInDate,
    B.CheckOutDate,
    B.BookingStatus
FROM Booking B
JOIN Customer C ON B.CustomerID = C.CustomerID
JOIN Room R ON B.RoomID = R.RoomID
JOIN Hotel H ON R.HotelID = H.HotelID;

-- ---------------------------------------------------------------
-- 2. Show total revenue collected from each hotel.
--    (Aggregation + JOIN + GROUP BY)
-- ---------------------------------------------------------------
SELECT 
    H.HotelName,
    SUM(P.Amount) AS TotalRevenue
FROM Payment P
JOIN Booking B ON P.BookingID = B.BookingID
JOIN Room R ON B.RoomID = R.RoomID
JOIN Hotel H ON R.HotelID = H.HotelID
WHERE P.PaymentStatus = 'Completed'
GROUP BY H.HotelName
ORDER BY TotalRevenue DESC;

-- ---------------------------------------------------------------
-- 3. Find customers who booked more than one room.
--    (GROUP BY + HAVING)
-- ---------------------------------------------------------------
SELECT 
    C.CustomerID,
    C.FullName,
    COUNT(B.BookingID) AS TotalBookings
FROM Customer C
JOIN Booking B ON C.CustomerID = B.CustomerID
GROUP BY C.CustomerID, C.FullName
HAVING COUNT(B.BookingID) > 1;

-- ---------------------------------------------------------------
-- 4. List all rooms that are currently booked.
--    (JOIN + WHERE filter)
-- ---------------------------------------------------------------
SELECT 
    R.RoomID,
    R.RoomNumber,
    R.AvailabilityStatus,
    H.HotelName
FROM Room R
JOIN Hotel H ON R.HotelID = H.HotelID
WHERE R.AvailabilityStatus = 'Booked';

-- ---------------------------------------------------------------
-- 5. Find top 5 most expensive room types based on price.
--    (ORDER BY + LIMIT)
-- ---------------------------------------------------------------
SELECT 
    TypeName,
    PricePerNight
FROM RoomType
ORDER BY PricePerNight DESC
LIMIT 5;

-- ---------------------------------------------------------------
-- 6. Find the hotel that has the highest number of bookings.
--    (Nested Subquery + GROUP BY)
-- ---------------------------------------------------------------
SELECT H.HotelName
FROM Hotel H
WHERE H.HotelID = (
    SELECT R.HotelID
    FROM Booking B
    JOIN Room R ON B.RoomID = R.RoomID
    GROUP BY R.HotelID
    ORDER BY COUNT(B.BookingID) DESC
    LIMIT 1
);

-- ---------------------------------------------------------------
-- 7. List all services used by customer "Ali Raza".
--    (JOIN across 4 tables)
-- ---------------------------------------------------------------
SELECT 
    C.FullName,
    S.ServiceName,
    BS.Quantity
FROM Booking_Service BS
JOIN Service S ON BS.ServiceID = S.ServiceID
JOIN Booking B ON BS.BookingID = B.BookingID
JOIN Customer C ON B.CustomerID = C.CustomerID
WHERE C.FullName = 'Ali Raza';

-- ---------------------------------------------------------------
-- 8. Find customers who have **never** made a booking.
--    (Nested subquery using NOT IN)
-- ---------------------------------------------------------------
SELECT 
    CustomerID,
    FullName
FROM Customer
WHERE CustomerID NOT IN (
    SELECT CustomerID FROM Booking
);

-- ---------------------------------------------------------------
-- 9. Get the average number of guests per hotel.
--    (Aggregation + multiple JOIN)
-- ---------------------------------------------------------------
SELECT 
    H.HotelName,
    AVG(B.NumberOfGuests) AS AvgGuests
FROM Booking B
JOIN Room R ON B.RoomID = R.RoomID
JOIN Hotel H ON R.HotelID = H.HotelID
GROUP BY H.HotelName
ORDER BY AvgGuests DESC;

-- ---------------------------------------------------------------
-- 10. Show total service charges added to each booking.
--     (JOIN + Aggregation)
-- ---------------------------------------------------------------
SELECT 
    B.BookingID,
    C.FullName,
    SUM(S.ServiceCharge * BS.Quantity) AS TotalServiceCost
FROM Booking_Service BS
JOIN Service S ON BS.ServiceID = S.ServiceID
JOIN Booking B ON BS.BookingID = B.BookingID
JOIN Customer C ON B.CustomerID = C.CustomerID
GROUP BY B.BookingID, C.FullName
ORDER BY TotalServiceCost DESC;

-- ===================================================================
-- END OF FILE
-- ===================================================================
