-- ============================================================
--  dbDDL.sql - HOTEL BOOKING SYSTEM (DDL SCRIPT)
-- ============================================================

-- 1. Drop existing database (for safety during re-runs)
DROP DATABASE IF EXISTS HotelBookingDB;

-- 2. Create new database
CREATE DATABASE HotelBookingDB;
USE HotelBookingDB;

-- ============================================================
--  TABLE 1: HOTEL
-- ============================================================
CREATE TABLE Hotel (
    HotelID INT AUTO_INCREMENT PRIMARY KEY,
    HotelName VARCHAR(100) NOT NULL,
    Location VARCHAR(150) NOT NULL,
    ContactNumber VARCHAR(20),
    Email VARCHAR(100),
    Rating DECIMAL(2,1) CHECK (Rating BETWEEN 0 AND 5)
);

-- Index to speed up hotel search
CREATE INDEX idx_hotel_location ON Hotel(Location);


-- ============================================================
--  TABLE 2: CUSTOMER
-- ============================================================
CREATE TABLE Customer (
    CustomerID INT AUTO_INCREMENT PRIMARY KEY,
    FullName VARCHAR(100) NOT NULL,
    Email VARCHAR(100) NOT NULL UNIQUE,
    PhoneNumber VARCHAR(20),
    Address VARCHAR(255),
    NationalID VARCHAR(50) UNIQUE
);

-- Index on Email for faster checking
CREATE INDEX idx_customer_email ON Customer(Email);


-- ============================================================
--  TABLE 3: ROOMTYPE
-- ============================================================
CREATE TABLE RoomType (
    RoomTypeID INT AUTO_INCREMENT PRIMARY KEY,
    TypeName VARCHAR(50) NOT NULL,
    Description VARCHAR(255),
    PricePerNight DECIMAL(10,2) NOT NULL CHECK (PricePerNight > 0)
);


-- ============================================================
--  TABLE 4: ROOM
-- ============================================================
CREATE TABLE Room (
    RoomID INT AUTO_INCREMENT PRIMARY KEY,
    HotelID INT NOT NULL,
    RoomTypeID INT NOT NULL,
    RoomNumber VARCHAR(10) NOT NULL,
    AvailabilityStatus ENUM('Available','Booked','Maintenance') DEFAULT 'Available',

    FOREIGN KEY (HotelID) REFERENCES Hotel(HotelID)
        ON DELETE CASCADE ON UPDATE CASCADE,

    FOREIGN KEY (RoomTypeID) REFERENCES RoomType(RoomTypeID)
        ON DELETE CASCADE ON UPDATE CASCADE,

    UNIQUE (HotelID, RoomNumber)
);

-- Efficient room lookups
CREATE INDEX idx_room_hotelid ON Room(HotelID);


-- ============================================================
--  TABLE 5: STAFF
-- ============================================================
CREATE TABLE Staff (
    StaffID INT AUTO_INCREMENT PRIMARY PRIMARY KEY,
    HotelID INT NOT NULL,
    FullName VARCHAR(100) NOT NULL,
    Role VARCHAR(50),
    ContactNumber VARCHAR(20),
    Email VARCHAR(100),

    FOREIGN KEY (HotelID) REFERENCES Hotel(HotelID)
        ON DELETE CASCADE ON UPDATE CASCADE
);


-- ============================================================
--  TABLE 6: BOOKING
-- ============================================================
CREATE TABLE Booking (
    BookingID INT AUTO_INCREMENT PRIMARY KEY,
    CustomerID INT NOT NULL,
    RoomID INT NOT NULL,
    CheckInDate DATE NOT NULL,
    CheckOutDate DATE NOT NULL,
    NumberOfGuests INT DEFAULT 1 CHECK (NumberOfGuests > 0),
    BookingStatus ENUM('Confirmed','CheckedIn','CheckedOut','Cancelled') DEFAULT 'Confirmed',

    FOREIGN KEY (CustomerID) REFERENCES Customer(CustomerID)
        ON DELETE CASCADE ON UPDATE CASCADE,

    FOREIGN KEY (RoomID) REFERENCES Room(RoomID)
        ON DELETE CASCADE ON UPDATE CASCADE
);

-- Index to find room availability quickly
CREATE INDEX idx_booking_roomid ON Booking(RoomID);


-- ============================================================
--  TABLE 7: PAYMENT
-- ============================================================
CREATE TABLE Payment (
    PaymentID INT AUTO_INCREMENT PRIMARY KEY,
    BookingID INT UNIQUE NOT NULL,
    PaymentDate DATE NOT NULL,
    PaymentMethod ENUM('Cash','Card','Online') NOT NULL,
    Amount DECIMAL(10,2) NOT NULL CHECK (Amount > 0),
    PaymentStatus ENUM('Pending','Completed','Refunded') DEFAULT 'Pending',

    FOREIGN KEY (BookingID) REFERENCES Booking(BookingID)
        ON DELETE CASCADE ON UPDATE CASCADE
);


-- ============================================================
--  TABLE 8: SERVICE
-- ============================================================
CREATE TABLE Service (
    ServiceID INT AUTO_INCREMENT PRIMARY KEY,
    ServiceName VARCHAR(100) NOT NULL,
    Description VARCHAR(255),
    ServiceCharge DECIMAL(10,2) NOT NULL CHECK (ServiceCharge >= 0)
);


-- ============================================================
--  TABLE 9: BOOKING_SERVICE (M-M RELATIONSHIP)
-- ============================================================
CREATE TABLE Booking_Service (
    BookingID INT NOT NULL,
    ServiceID INT NOT NULL,
    Quantity INT DEFAULT 1 CHECK (Quantity > 0),

    PRIMARY KEY (BookingID, ServiceID),

    FOREIGN KEY (BookingID) REFERENCES Booking(BookingID)
        ON DELETE CASCADE ON UPDATE CASCADE,

    FOREIGN KEY (ServiceID) REFERENCES Service(ServiceID)
        ON DELETE CASCADE ON UPDATE CASCADE
);


-- ============================================================
--  OPTIONAL OBJECT 1: VIEW (Hotel Booking Summary)
-- ============================================================
CREATE VIEW BookingSummary AS
SELECT 
    b.BookingID,
    c.FullName AS CustomerName,
    h.HotelName,
    r.RoomNumber,
    b.CheckInDate,
    b.CheckOutDate,
    b.BookingStatus
FROM Booking b
JOIN Customer c ON b.CustomerID = c.CustomerID
JOIN Room r ON b.RoomID = r.RoomID
JOIN Hotel h ON r.HotelID = h.HotelID;


-- ============================================================
--  OPTIONAL OBJECT 2: TRIGGER (Auto-update room status)
-- ============================================================
DELIMITER $$

CREATE TRIGGER tr_update_room_status_after_booking
AFTER INSERT ON Booking
FOR EACH ROW
BEGIN
    UPDATE Room
    SET AvailabilityStatus = 'Booked'
    WHERE RoomID = NEW.RoomID;
END$$

DELIMITER ;



