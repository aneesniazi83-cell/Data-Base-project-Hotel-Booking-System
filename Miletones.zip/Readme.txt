How to run these files:-
Open MySQL Workbench
Top menu → File → Open SQL Script
Browse → select your file:
Run in this order:
1️ dbDDL.sql (creates tables)
2️ dbDML.sql (inserts sample data)
3️ dbSQL.sql (runs analytical queries)