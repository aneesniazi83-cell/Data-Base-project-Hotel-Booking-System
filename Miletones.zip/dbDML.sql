-- =============================================================
-- dbDML.sql - Sample Data for Hotel Booking System
-- =============================================================

USE HotelBookingDB;

SET FOREIGN_KEY_CHECKS = 0;

-- =============================================================
-- 1. HOTEL TABLE (15 rows)
-- =============================================================
INSERT INTO Hotel (HotelName, Location, ContactNumber, Email, Rating) VALUES
('Grand Palace Hotel', 'Karachi', '021-1111111', 'info@grandpalace.com', 4.5),
('Royal Heritage Hotel', 'Lahore', '042-2222222', 'contact@royalheritage.com', 4.2),
('Sunrise Continental', 'Islamabad', '051-3333333', 'support@sunrise.com', 4.7),
('City Star Residency', 'Faisalabad', '041-4444444', 'hello@citystar.com', 4.0),
('Luxury Suites Inn', 'Karachi', '021-5555555', 'lux@suites.com', 4.3),
('Pearl Executive Hotel', 'Lahore', '042-6666666', 'pearl@executive.com', 4.8),
('Blue Orchid Resort', 'Islamabad', '051-7777777', 'blue@orchid.com', 4.6),
('Comfort Stay Hotel', 'Quetta', '081-8888888', 'contact@comfort.com', 3.9),
('Dreamland Grand', 'Multan', '061-9999999', 'dream@grand.pk', 4.4),
('Midtown Deluxe', 'Peshawar', '091-1010101', 'midtown@deluxe.com', 4.1),
('Elite Palace', 'Karachi', '021-2020202', 'elite@palace.com', 4.6),
('Hotel Evergreen', 'Sialkot', '052-3030303', 'info@evergreen.com', 4.0),
('MetroView Plaza', 'Karachi', '021-4040404', 'metro@view.com', 4.3),
('Serene Residency', 'Islamabad', '051-5050505', 'serene@res.com', 4.5),
('Paradise Comforts', 'Lahore', '042-6060606', 'paradise@comforts.com', 4.7);

-- =============================================================
-- 2. CUSTOMER TABLE (15 rows)
-- =============================================================
INSERT INTO Customer (FullName, Email, PhoneNumber, Address, NationalID) VALUES
('Ali Raza', 'ali.raza@mail.com', '0300-1111111', 'Karachi', '42101-1111111-1'),
('Sara Khan', 'sara.khan@mail.com', '0301-2222222', 'Lahore', '35201-2222222-2'),
('Ahmed Malik', 'ahmed.malik@mail.com', '0302-3333333', 'Islamabad', '61101-3333333-3'),
('Fatima Noor', 'fatima.noor@mail.com', '0303-4444444', 'Karachi', '42102-4444444-4'),
('Bilal Ahmed', 'bilal.ahmed@mail.com', '0304-5555555', 'Faisalabad', '33101-5555555-5'),
('Hira Sheikh', 'hira.sheikh@mail.com', '0305-6666666', 'Quetta', '54401-6666666-6'),
('Umer Farooq', 'umer.farooq@mail.com', '0306-7777777', 'Karachi', '42101-7777777-7'),
('Maryam Zahid', 'maryam.zahid@mail.com', '0307-8888888', 'Lahore', '35201-8888888-8'),
('Hamza Ali', 'hamza.ali@mail.com', '0308-9999999', 'Multan', '61101-9999999-9'),
('Ayesha Siddiqui', 'ayesha.sid@mail.com', '0310-1212121', 'Peshawar', '54201-1212121-2'),
('Zain Abbas', 'zain.abbas@mail.com', '0321-3434343', 'Karachi', '42101-3434343-3'),
('Hassan Raza', 'hassan.raza@mail.com', '0333-4545454', 'Lahore', '35201-4545454-5'),
('Nida Iqbal', 'nida.iqbal@mail.com', '0311-5656565', 'Islamabad', '61101-5656565-6'),
('Asad Mehmood', 'asad.mehmood@mail.com', '0345-6767676', 'Karachi', '42101-6767676-7'),
('Laiba Shaikh', 'laiba.shaikh@mail.com', '0320-7878787', 'Lahore', '35201-7878787-8');

-- =============================================================
-- 3. ROOMTYPE TABLE (15 rows)
-- =============================================================
INSERT INTO RoomType (TypeName, Description, PricePerNight) VALUES
('Standard', 'Standard non-AC room', 4500),
('Deluxe', 'Deluxe AC room', 6500),
('Executive', 'Executive king-size room', 9000),
('Suite', 'Luxury suite room', 12000),
('Twin Bed', 'Room with two beds', 5500),
('Single Bed', 'Room with one bed', 4000),
('Family Room', 'Room suitable for families', 11000),
('Economy', 'Budget-friendly room', 3500),
('Premium', 'Premium furnished room', 7500),
('Luxury Suite', 'Lavish suite with premium features', 15000),
('Business Class', 'Business traveler room', 9500),
('Honeymoon Suite', 'Romantic private suite', 16000),
('Panoramic View', 'Room with skyline view', 13000),
('Queen Deluxe', 'Queen-size deluxe room', 7000),
('Royal Executive', 'Royal style executive room', 14000);

-- =============================================================
-- 4. ROOM TABLE (15 rows)
-- =============================================================
INSERT INTO Room (HotelID, RoomTypeID, RoomNumber, AvailabilityStatus) VALUES
(1, 2, '101', 'Available'),
(1, 3, '102', 'Available'),
(1, 4, '103', 'Maintenance'),
(2, 1, '201', 'Available'),
(2, 5, '202', 'Booked'),
(3, 6, '301', 'Available'),
(3, 7, '302', 'Booked'),
(4, 8, '401', 'Available'),
(4, 9, '402', 'Available'),
(5, 10, '501', 'Booked'),
(6, 11, '601', 'Available'),
(7, 12, '701', 'Available'),
(8, 13, '801', 'Booked'),
(9, 14, '901', 'Available'),
(10, 15, '1001', 'Booked');

-- =============================================================
-- 5. STAFF TABLE (15 rows)
-- =============================================================
INSERT INTO Staff (HotelID, FullName, Role, ContactNumber, Email) VALUES
(1, 'Imran Ali', 'Manager', '0300-1234567', 'imran@grand.com'),
(1, 'Shahid Khan', 'Receptionist', '0301-2345678', 'shahid@grand.com'),
(2, 'Kamran Malik', 'Chef', '0302-3456789', 'kamran@royal.com'),
(2, 'Arif Hussain', 'Security', '0303-4567890', 'arif@royal.com'),
(3, 'Adeel Khan', 'Manager', '0304-5678901', 'adeel@sunrise.com'),
(3, 'Usman Ali', 'Receptionist', '0305-6789012', 'usman@sunrise.com'),
(4, 'Rashid Mehmood', 'Chef', '0306-7890123', 'rashid@citystar.com'),
(5, 'Noman Javed', 'Manager', '0307-8901234', 'noman@lux.com'),
(6, 'Farhan Ahmed', 'Security', '0308-9012345', 'farhan@pearl.com'),
(7, 'Irfan Saeed', 'Manager', '0309-0123456', 'irfan@orchid.com'),
(8, 'Waseem Akhtar', 'Receptionist', '0311-0987654', 'waseem@comfort.com'),
(9, 'Haroon Shah', 'Manager', '0322-2345671', 'haroon@dream.com'),
(10, 'Adnan Raza', 'Chef', '0333-3456782', 'adnan@midtown.com'),
(11, 'Talha Iqbal', 'Manager', '0345-4567812', 'talha@elite.com'),
(12, 'Zeeshan Malik', 'Security', '0355-5678912', 'zeeshan@evergreen.com');

-- =============================================================
-- 6. BOOKING TABLE (15 rows)
-- =============================================================
INSERT INTO Booking (CustomerID, RoomID, CheckInDate, CheckOutDate, NumberOfGuests, BookingStatus) VALUES
(1, 1, '2025-01-10', '2025-01-12', 2, 'Confirmed'),
(2, 2, '2025-01-11', '2025-01-13', 1, 'CheckedIn'),
(3, 3, '2025-01-12', '2025-01-14', 3, 'Cancelled'),
(4, 4, '2025-01-13', '2025-01-15', 2, 'Confirmed'),
(5, 5, '2025-01-14', '2025-01-16', 2, 'CheckedIn'),
(6, 6, '2025-01-15', '2025-01-17', 1, 'Confirmed'),
(7, 7, '2025-01-16', '2025-01-18', 4, 'CheckedOut'),
(8, 8, '2025-01-17', '2025-01-19', 2, 'Confirmed'),
(9, 9, '2025-01-18', '2025-01-20', 1, 'Confirmed'),
(10, 10, '2025-01-19', '2025-01-21', 2, 'Cancelled'),
(11, 11, '2025-01-20', '2025-01-22', 2, 'Confirmed'),
(12, 12, '2025-01-21', '2025-01-23', 1, 'CheckedIn'),
(13, 13, '2025-01-22', '2025-01-24', 3, 'Confirmed'),
(14, 14, '2025-01-23', '2025-01-25', 2, 'CheckedOut'),
(15, 15, '2025-01-24', '2025-01-26', 1, 'Confirmed');

-- =============================================================
-- 7. PAYMENT TABLE (15 rows)
-- =============================================================
INSERT INTO Payment (BookingID, PaymentDate, PaymentMethod, Amount, PaymentStatus) VALUES
(1, '2025-01-10', 'Card', 9000, 'Completed'),
(2, '2025-01-11', 'Online', 13000, 'Completed'),
(3, '2025-01-12', 'Cash', 24000, 'Refunded'),
(4, '2025-01-13', 'Card', 9000, 'Completed'),
(5, '2025-01-14', 'Cash', 13000, 'Completed'),
(6, '2025-01-15', 'Online', 9000, 'Completed'),
(7, '2025-01-16', 'Card', 18000, 'Completed'),
(8, '2025-01-17', 'Cash', 9000, 'Completed'),
(9, '2025-01-18', 'Card', 7500, 'Completed'),
(10, '2025-01-19', 'Cash', 15000, 'Refunded'),
(11, '2025-01-20', 'Online', 9000, 'Completed'),
(12, '2025-01-21', 'Card', 16000, 'Completed'),
(13, '2025-01-22', 'Cash', 18000, 'Completed'),
(14, '2025-01-23', 'Card', 15000, 'Completed'),
(15, '2025-01-24', 'Online', 7500, 'Completed');

-- =============================================================
-- 8. SERVICE TABLE (15 rows)
-- =============================================================
INSERT INTO Service (ServiceName, Description, ServiceCharge) VALUES
('Breakfast', 'Buffet breakfast', 800),
('Laundry', 'Washing and ironing', 500),
('Airport Pickup', 'Pickup service', 2000),
('Spa', 'Full body spa', 3000),
('Gym Access', 'Access to fitness club', 1000),
('Mini Bar', 'Snacks and drinks', 1500),
('Car Rental', 'Private car hire', 3500),
('Dinner', 'Dinner buffet', 1200),
('Pool Access', 'Swimming pool entry', 700),
('Room Cleaning', 'Daily cleaning', 400),
('WiFi', 'High-speed internet', 300),
('Massage', 'Relaxing massage service', 2500),
('Sauna', 'Sauna room', 2000),
('Tea/Coffee', 'Complimentary drinks', 200),
('VIP Transport', 'Luxury car transport', 6000);

-- =============================================================
-- 9. BOOKING_SERVICE TABLE (15 rows)
-- =============================================================
INSERT INTO Booking_Service (BookingID, ServiceID, Quantity) VALUES
(1, 1, 2),
(1, 2, 1),
(2, 3, 1),
(3, 4, 1),
(4, 5, 2),
(5, 6, 1),
(6, 7, 1),
(7, 8, 2),
(8, 9, 1),
(9, 10, 1),
(10, 11, 1),
(11, 12, 1),
(12, 13, 2),
(13, 14, 1),
(15, 15, 1);

SET FOREIGN_KEY_CHECKS = 1;

-- =============================================================
-- END OF DML SCRIPT
-- =============================================================
